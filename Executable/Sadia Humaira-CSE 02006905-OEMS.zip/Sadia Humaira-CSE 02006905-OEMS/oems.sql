-- MySQL dump 10.13  Distrib 5.7.39, for Win32 (AMD64)
--
-- Host: localhost    Database: oems
-- ------------------------------------------------------
-- Server version	5.7.39-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `admin`
--

DROP TABLE IF EXISTS `admin`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `admin` (
  `username` varchar(100) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `admin`
--

LOCK TABLES `admin` WRITE;
/*!40000 ALTER TABLE `admin` DISABLE KEYS */;
INSERT INTO `admin` VALUES ('admin','oems');
/*!40000 ALTER TABLE `admin` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `id` varchar(10) DEFAULT NULL,
  `name` varchar(500) DEFAULT NULL,
  `opt1` varchar(500) DEFAULT NULL,
  `opt2` varchar(500) DEFAULT NULL,
  `opt3` varchar(500) DEFAULT NULL,
  `opt4` varchar(500) DEFAULT NULL,
  `answer` varchar(500) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES ('1','Software is defined as ___________','set of programs, documentation & configuration of data','set of program','documentation and configuration of data','None of the mentioned','set of programs, documentation & configuration of data'),('2','What is Software Engineering?','Designing a software','Testing a software','Application of engineering principles to the design a software','None of the above','Application of engineering principles to the design a software'),('3','Who is the father of Software Engineering?','Margaret Hamilton','Watts S. Humphrey','Alan Turing','Boris Beizer','Watts S. Humphrey'),('4',' What are the features of Software Code?','Simplicity','Accessibility','Modularity','All of the above','Modularity'),('5','____________ is a software development activity that is not a part of software processes.','Validation','Specification','Development','Dependence','Dependence'),('6','Define Agile scrum methodology.','project management that emphasizes incremental progress',' project management that emphasizes decremental progress','project management that emphasizes neutral progress','project management that emphasizes no progress','project management that emphasizes incremental progress'),('7','What is a Functional Requirement?',' specifies the tasks the program must complete','specifies the tasks the program should not complete',' specifies the tasks the program must not work','All of the mentioned',' specifies the tasks the program must complete'),('8','Why do bugs and failures occur in software?','Because of Developers','Because of companies','Because of both companies & Developers','None of the mentioned','Because of both companies & Developers'),('9',' Attributes of good software is ____________','Development','Maintainability & functionality','Functionality','Maintainability','Maintainability & functionality'),('10',' Agile Software Development is based on which of the following type?','Iterative Development','Incremental Development',' Both Incremental and Iterative Development','Linear Development','Both Incremental and Iterative Development');
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `r_id` int(11) NOT NULL AUTO_INCREMENT,
  `opinion` varchar(55) DEFAULT NULL,
  `st_id` varchar(10) DEFAULT NULL,
  PRIMARY KEY (`r_id`)
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,'Standard','106'),(2,'Average','107'),(3,'Standard','100'),(4,'Average','101'),(5,'Tough','102'),(6,'Average','103'),(7,'Good','104'),(8,'Tough','105'),(9,'Good','105'),(10,'Standard','106'),(11,'Tough','108'),(12,'Good','110'),(13,'Standard','109'),(14,'Tough','110'),(15,'Tough','110'),(16,'Good','110'),(17,'Tough','110'),(18,'Good','110');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student`
--

DROP TABLE IF EXISTS `student`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `student` (
  `id` varchar(10) DEFAULT NULL,
  `name` varchar(100) DEFAULT NULL,
  `gender` varchar(50) DEFAULT NULL,
  `mobile_no` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `marks` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student`
--

LOCK TABLES `student` WRITE;
/*!40000 ALTER TABLE `student` DISABLE KEYS */;
INSERT INTO `student` VALUES ('100','Shahin','Male','237284676375','shahin@gmail.com',8),('101','Sadia','Female','32143253456','sadia@gmail.com',5),('102','Taspiya','Female','8987543423','taspi@gmail.com',4),('103','Neha','Female','01257358990','neha@gmail.com',7),('104','Rihan','Male','1312354598','rihan@gmail.com',8),('105','Sammi','Female','121334234444','sammi@gmail.com',6),('106','Raisa','Female','1321343535','raisa@gmail.com',8),('108','Arif','Male','123456788988','arif@gmail.com',5),('109','Mark Kave','Male','98677203232','mark@gmail.com',9),('110','Jennifer ','Female','0123785437','jeni10@gmail.com',4);
/*!40000 ALTER TABLE `student` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2022-08-08 22:40:27
